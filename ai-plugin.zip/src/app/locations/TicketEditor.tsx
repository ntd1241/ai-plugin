import React from 'react';
import { useEffect, useState, useRef } from 'react';
import { useClient } from '../hooks/useClient'
import { Button } from "@primitives/button"
import { Separator } from '@primitives/separator'
import {
    IconArrowBackUp,
    IconArrowForwardUp,
    IconTextSpellcheck,
    IconTextDecrease,
    IconTextIncrease,
    IconRefresh
} from '@tabler/icons-react'
// import UseAnimations from "react-useanimations";
// import github from 'react-useanimations/lib/github';

interface ActionStatusProps {
    title: string,
    description: string,
}

function ActionStatus() {

    return (
        <div className='flex flex-col'>
            <div className='flex flex-row px-2 py-1.5 place-items-center'>
                <div className='px-2 py-1.5 flex-1'>
                    <div className='menu-title text-jarvis-5'>Response Toolbox</div>
                </div>
            </div>
            <Separator />
            <div className='flex flex-row px-4 py-3 space-x-4'>
                {/* <UseAnimations animation={github} size={24} /> */}
                <div className='flex flex-row place-items-center'>
                    Hello 2131232sda
                </div>
            </div>
        </div>
    );
}

function Menu() {

    return (
        <div className='flex flex-col'>
            <div className='flex flex-row px-2 py-1.5 place-items-center'>
                <div className='px-2 py-1.5 flex-1'>
                    <div className='menu-title text-jarvis-5'>Response Toolbox</div>
                </div>
                <div className='space-x-1'>
                    <Button variant={'outline'} size={'icon'} disabled><IconArrowBackUp className='size-4 text-jarvis-5' /></Button>
                    <Button variant={'outline'} size={'icon'} disabled><IconArrowForwardUp className='size-4 text-jarvis-5' /></Button>
                </div>
            </div>
            <Separator />
            <div className='flex flex-col px-2 py-1.5'>
                <div className='px-2 py-1.5'>
                    <div className='menu-section'>Formalization</div>
                </div>
                <Button variant={'ghost'}>
                    <div className='flex flex-row w-full place-items-center'>
                        <IconTextSpellcheck className='size-4 mr-2 text-jarvis-5' /> Correct grammar
                    </div>
                </Button>
                <Button variant={'ghost'}>
                    <div className='flex flex-row w-full place-items-center'>
                        <IconTextDecrease className='size-4 mr-2 text-jarvis-5' /> Shorten response
                    </div>
                </Button>
                <Button variant={'ghost'}>
                    <div className='flex flex-row w-full place-items-center'>
                        <IconTextIncrease className='size-4 mr-2 text-jarvis-5' /> Lengthen response
                    </div>
                </Button>
            </div>
            <Separator />
            <div className='flex flex-col px-2 py-1.5'>
                <Button variant={'primary'}>
                    <div className='flex flex-row w-full place-items-center'>
                        <IconRefresh className='size-4 mr-2' /> Draft response
                    </div>
                </Button>
            </div>
        </div>
    );
}

const TicketEditor = () => {

    const client: any = useClient();
    useEffect(() => {
        client.invoke('resize', { width: '248px' })
    }, [client])

    const [height, setHeight] = useState(0)
    const ref = useRef<HTMLDivElement>(null)

    useEffect(() => {
        if (ref.current != null) setHeight(ref.current.clientHeight);
        client.invoke('resize', { height: height });
    }, [setHeight])

    const [component, setComponent] = useState(<Menu />);

    return (
        <div ref={ref}>
            <div>Hello</div>
        </div>
    );
}

export default TicketEditor;
